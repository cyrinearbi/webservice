import ky from 'ky';

(async () => {
    const parsed = await ky.get('https://swapi.co/api/planets/?format=json').json();
    const oo = await ky.get('https://swapi.co/api/planets/?format=json').json();

console.log(parsed);
console.log(oo);
//=> `{data: '🦄'}`

})();

/*
(async () => {
    const xx = await ky.post('https://swapi.co/api/planets/?format=json', {json: {foo: true}}).json();

    console.log(xx);
//=> `{data: '🦄'}`

})();*/

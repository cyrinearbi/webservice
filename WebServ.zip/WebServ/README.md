# ws

# genrer le main.js automatique use 
npx webpack --watch

# pour lancer le projet use
 serve .

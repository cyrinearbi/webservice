import ky from 'ky';

(async () => {
    const parsed = await ky.get('http://api.geonames.org/citiesJSON?north=44.1&south=-9.9&east=-22.4&west=55.2&lang=de&username=demo', { json: {foo: true}} ).json();

console.log(parsed);
//=> `{data: '🦄'}`

})();
